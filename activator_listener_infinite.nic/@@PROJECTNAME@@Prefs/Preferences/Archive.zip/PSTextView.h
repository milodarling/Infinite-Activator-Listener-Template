#import <UIKit/UIKit.h>
#import <UIKit/UITextContentView.h>

@interface PSTextView : UITextContentView {
    id _cell;
}

- (void)setCell:(id)arg1;

@end